import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { CryptoComponent } from './crypto/crypto.component';
import { AlgoComponent } from './algo/algo.component';
import { CompComponent } from './comp/comp.component';
import { InternetComponent } from './internet/internet.component';
import { AiComponent } from './ai/ai.component';
import { ProgComponent } from './prog/prog.component';
import { SecretComponent } from './secret/secret.component';
import { NotFoundComponent } from './not-found/not-found.component';

const routes: Routes = [
  { path: 'crypto', component: CryptoComponent, pathMatch: 'full'},
  { path: '', component: HomeComponent, pathMatch: 'full'},
  { path: 'algo', component: AlgoComponent, pathMatch: 'full'},
  { path: 'comp', component: CompComponent, pathMatch: 'full'},
  { path: 'internet', component: InternetComponent, pathMatch: 'full'},
  { path: 'ai', component: AiComponent, pathMatch: 'full'},
  { path: 'prog', component: ProgComponent, pathMatch: 'full'},
  { path: 'secret/:key', component: SecretComponent, pathMatch: 'full'},
  { path: '404', component: NotFoundComponent, pathMatch: 'full'},
  { path: '**', redirectTo: '/404'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
