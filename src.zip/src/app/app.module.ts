import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app/app.component';
import { AiComponent } from './ai/ai.component';
import { FormComponent } from './form/form.component';
import { AwesomifyPipe } from './awesomify.pipe';
import { AlphaPipe } from './alpha.pipe';
import { MagnifyDirective } from './magnify.directive';
import { NavigationComponent } from './navigation/navigation.component';
import { SubjectComponent } from './subject/subject.component';
import { HomeComponent } from './home/home.component';
import { CryptoComponent } from './crypto/crypto.component';
import { AlgoComponent } from './algo/algo.component';
import { CompComponent } from './comp/comp.component';
import { InternetComponent } from './internet/internet.component';
import { ProgComponent } from './prog/prog.component';
import { SecretComponent } from './secret/secret.component';
import { NotFoundComponent } from './not-found/not-found.component';

@NgModule({
  declarations: [
    AppComponent,
    AiComponent,
    FormComponent,
    AwesomifyPipe,
    AlphaPipe,
    MagnifyDirective,
    NavigationComponent,
    SubjectComponent,
    HomeComponent,
    CryptoComponent,
    AlgoComponent,
    CompComponent,
    InternetComponent,
    ProgComponent,
    SecretComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, 
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
